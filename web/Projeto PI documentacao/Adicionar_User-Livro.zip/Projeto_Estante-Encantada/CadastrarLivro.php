<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastrar novo Livro</title>
    </head>                     
    <body>
        <main>
            <section>
                <form action="model/Livro.php" method="post">
                    <div>
                        <label for="txtNomeL">Nome do Livro</label>
                        <input type="text" id="txtNomeL" name="nomeL">
                    </div>
                    <div>
                        <label for="txtValor">Preço do Livro</label> 
                        <input type="text" id="txtValor" name="valorL">
                    </div>
                    <div>
                        <label for="txtQuantidade">Quantidade de Exemplares</label>
                        <input type="number" min="0" id="txtQuantidade" name="quantidadeL">
                    </div>
                    <!--<div>
                        <label for="txtQuantidade">Quantidade de Exemplares</label>
                    </div>-->
                    <div>
                        <input type="submit" value="Salvar" name="salvarDados">
                    </div>
                    <div>
                        <input type="reset" value="Limpar Campos" name="limparCampos">
                    </div>
                </form>
            </section>
        </main>
    </body>
</html>
