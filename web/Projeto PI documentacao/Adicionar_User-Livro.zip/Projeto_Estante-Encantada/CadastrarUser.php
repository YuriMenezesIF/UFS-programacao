<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Cadastrar novo Usuário</title>
    </head>                     
    <body>
        <main>
            <section>
                <form action="model/Usuario.php" method="post">
                    <div>
                        <label for="txtNome">Nome</label>
                        <input type="text" id="txtNome" name="nome">
                    </div>
                    <div>
                        <label for="txtEmail">e-mail</label> 
                        <input type="email" id="txtEmail" name="email">
                    </div>
                    <div>
                        <label for="txtSenha">Senha</label>
                        <input type="password" id="txtSenha" name="senha">
                    </div>
                    <div>
                        <input type="submit" value="Salvar" name="salvarDados">
                    </div>
                    <div>
                        <input type="reset" value="Limpar Campos" name="limparCampos">
                    </div>
                </form>
            </section>
        </main>
    </body>
</html>
