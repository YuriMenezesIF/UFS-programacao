<?php

session_start();
?>
<!DOCTYPE html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Métodos HTTP</title>
  </head>
  <body>
    <main>
      <h1>Fazer login</h1>
      <a href="sobre.php">Sobre</a>
      <br>
      <form action="restrita.php" method="post">
       <article class="entradaDados">
          <label>Nome</label>
          <input type="nome" name="nome" placeholder="Digite seu nome">
        </article> 

        <article class="entradaDados">
          <label>Email</label>
          <input type="email" name="email" placeholder="Digite seu e-mail">
        </article>

        <article class="entradaDados">
          <label>Senha:</label>
          <input type="password" name="senha" placeholder="Digite sua senha">
        </article>
        <br>
        <article class="entradaDados">
          <?php if(isset($_SESSION["usuario"])): ?>
            <a href="logout.php">
                <?= $_SESSION["usuario"]; ?>
            </a>
          <?php else: ?>
          <input type="submit" value="Enviar">
        <?php endif; ?>
        </article>
      </form>
      <article class="entradaDados">
        <?php
          //if (isset($_GET["msg"])) {
          //  if ($_GET["msg"] != "") {
          //    echo $_GET["msg"];
              $_GET["msg"] = "";
          //  }
          //}

          if (isset($_SESSION["msg"])) {
            echo $_SESSION["msg"];
            unset($_SESSION["msg"]);
          }
        ?>
      </article>
    </main>
  </body>
</html>
