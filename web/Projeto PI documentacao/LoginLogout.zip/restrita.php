<?php
  
  
  //Inicia as sessões ($_SESSION) do PHP
  session_start();
  $loginOK = true;
  $file =file_get_contents("bd/usuario.bd");

  $pnome=$_POST["nome"];
  $pemail=$_POST["email"];
  $psenha=$_POST["senha"];
  $nome="/$pnome/";
  $email="/$pemail/";
  $senha="/$psenha/";

   //if($_POST["nome"]=="") & ($_POST["email"]=="") & ($_POST["senha"]==""){
    // $_SESSION["msg"] = "Preencha os campos   ";
    // header("Location: ../index.php");
   //}
   if($_POST["nome"]=="") {
     $_SESSION["msg"] = "Digite algum nome! ";
     header("Location: ../index.php");
   }
   if($_POST["email"]==""){
     $_SESSION["msg"] = "Digite algum email! ";
     header("Location: ../index.php");
   }
   if($_POST["senha"]==""){
     $_SESSION["msg"] = "Digite alguma senha! ";
     header("Location: ../index.php");
   }
  if(!preg_match($nome, $file)) {
    $_SESSION["msg"] = "Nome não encontrado!";
    header("Location: ../index.php");

  }if(!preg_match($email, $file)) {
    $_SESSION["msg"] = "Email inválida!";
    header("Location: ../index.php");

  }if(!preg_match($senha, $file)) {
    $_SESSION["msg"] = "Senha inválida!";
    header("Location: ../index.php");
  }
  else{
    $_SESSION["usuário"] = $_POST["email"];
  }
  
  
     
  
  
?>
<!DOCTYPE html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <title>Restrita</title>
  </head>
  <body>
    <h2>Dados do formulário</h2>

    <?php
      // Para testar se os dados estão chegando corretamente
      //print_r($_GET);

      echo "Você logou com o nome " .$_POST["nome"]; 
      echo " e com o e-mail " . $_POST["email"];
      echo " e com a senha " . $_POST["senha"];
    ?>
    <a href="sobre.php">Sobre</a> 
    <a href="index.php">Logout</a>
  </body>
</html>
