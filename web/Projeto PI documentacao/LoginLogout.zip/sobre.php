<?php
  session_start();
  if (! isset($_SESSION["usuario"])) {
    $_SESSION["msg"] = "Faça login para acesar o conteúdo";
    header("Location: index.php");
  }
  ?>
<!DOCTYPE html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <title>Sobre</title>
  </head>
  <body>
    <?php

      echo "Usuário logado: " . $_SESSION["usuario"];
     ?>
  </body>
</html>
