
package br.edu.ifrn.pi.ips.conexao;

import br.edu.ifrn.pi.ips.dominio.Curso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CursoDAO {
        public boolean inserir(Curso curso) {

        boolean resultado = false;
        String inserir = "INSERT INTO Curso(nome, id) VALUES(?,?)";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(inserir);

            comando.setString(1, curso.getNome());
            comando.setInt(2, curso.getId());
           
           
            comando.execute();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public List<Curso> selecionarCursos() {

        ArrayList<Curso> lista = new ArrayList<Curso>();
        
        PreparedStatement comando = null;
        
        String selecionarCursos = "SELECT * FROM Curso";

        Connection con = Conexao.conectar();

        try {

            comando = con.prepareStatement(selecionarCursos);
            
            ResultSet rSet = comando.executeQuery();

            while (rSet.next()) {

                Curso c1 = new Curso();

                c1.setNome(rSet.getString("nome"));
                c1.setId(rSet.getInt("id"));
               
                
                lista.add(c1);

            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return lista;
    }
}
