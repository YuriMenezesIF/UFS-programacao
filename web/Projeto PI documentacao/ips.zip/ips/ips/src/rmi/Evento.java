/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package rmi;

import java.io.Serializable;

public class Evento implements Serializable {

     private String gol;
     private String falta;
     private String nomeTime;

    public Evento(String gol, String falta, String nomeTime) {
        this.gol = gol;
        this.falta = falta;
        this.nomeTime = nomeTime;
    }
     
    public String getGol() {
        return gol;
    }

    public void setGol(String gol) {
        this.gol = gol;
    }

    public String getFalta() {
        return falta;
    }

    public void setFalta(String falta) {
        this.falta = falta;
    }

    public String getNomeTime() {
        return nomeTime;
    }

    public void setNomeTime(String nomeTime) {
        this.nomeTime = nomeTime;
    }
     
     
    
}
