package br.edu.ifrn.pi.ips.conexao;

import br.edu.ifrn.pi.ips.dominio.Jogador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class JogadorDAO {

    public boolean inserir(Jogador jogador) {

        boolean resultado = false;
        String inserir = "INSERT INTO Jogador(nome, matricula) VALUES(?,?)";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(inserir);

            comando.setString(1, jogador.getNome());
            comando.setString(2, jogador.getMatricula());
           
            comando.execute();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public boolean remover(String matricula) {

        boolean resultado = false;
        String remover = "DELETE FROM Jogador WHERE matricula = ?";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(remover);

            comando.setString(1, matricula);

            comando.execute();
            resultado = true;

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public boolean atualizar(Jogador jogador) {

        boolean resultado = false;

        String atualizar = "UPDATE Jogador set nome = ?, matricula = ?, numero = ? WHERE matricula = ?";
        
        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(atualizar);

            comando.setString(1, jogador.getNome());
            comando.setString(2, jogador.getMatricula());
            comando.setInt(3, jogador.getNumero());

            comando.execute();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public Jogador buscarJogador(String matricula) {

        Jogador jogador1 = null;

        String queryInserir = "SELECT nome, matricula FROM Jogador WHERE Matricula = ?";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(queryInserir);
            comando.setString(1, matricula);
            
            ResultSet rSet = comando.executeQuery();

            if (rSet.next()) {
                jogador1 = new Jogador();

                jogador1.setNome(rSet.getString("nome"));
                
                jogador1.setNumero(rSet.getInt("matricula"));
            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return jogador1;
    }

    public List<Jogador> buscarUsuarios(String matricula) {

        ArrayList<Jogador> lista = new ArrayList<Jogador>();

        String queryInserir = "SELECT nome, matricula, numero FROM Jogador WHERE matricula = ?";

        System.out.println(matricula);

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(queryInserir);
            comando.setString(1, matricula);
            ResultSet rSet = comando.executeQuery();

            while (rSet.next()) {

                Jogador j2 = new Jogador();

                j2.setNome(rSet.getString("nome"));
                j2.setMatricula(rSet.getString("matricula"));
                j2.setNumero(rSet.getInt("numero"));
                
                lista.add(j2);

            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return lista;
    }

}
