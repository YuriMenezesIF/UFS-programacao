/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrn.pi.ips.conexao;

import br.edu.ifrn.pi.ips.dominio.Curso;
import br.edu.ifrn.pi.ips.dominio.Jogador;
import br.edu.ifrn.pi.ips.dominio.Time;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Yuri
 */
public class TimeDAO {
    
    public boolean inserirTime(Time time) {

        boolean resultado = false;
        String inserir = "INSERT INTO Time(nome, curso_id, modalidade_id) VALUES(?,?,?)";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(inserir);

            comando.setString(1, time.getNome());
            comando.setInt(2, time.getCurso().getId());
            comando.setInt(3, time.getModalidade().getId());

            comando.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public boolean inserirJog(Jogador jogador, Time time) {
        
        boolean resultado = false;
        String inserirJog = "INSERT INTO Jogador_time (jogador_matricula, time_nome) VALUES (?, ?);";
        
        Connection con = Conexao.conectar();

        try {
            PreparedStatement comando = con.prepareStatement(inserirJog);
            
            comando.setString(1, jogador.getMatricula());
            comando.setString(2, time.getNome());
            System.out.println(comando);
            
            comando.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally{
            Conexao.desconectar();
        }
        return resultado;
    }
    
    public boolean atualizarNumeros(Time time, List<Jogador> jogadores){
        
        boolean resultado = false;
        String atualizar = "UPDATE jogador_time SET numero_jogador = ? WHERE time_nome = ? AND jogador_matricula = ?;";
        
        Connection con = Conexao.conectar();
        
        try {

            PreparedStatement comando = con.prepareStatement(atualizar);

            for (int i = 0; i < jogadores.size(); i++){
                comando.setInt(1, jogadores.get(i).getNumero());
                comando.setString(2, time.getNome());
                comando.setString(3, jogadores.get(i).getMatricula());
            
                comando.execute();
            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public boolean remover(String nome) {

        boolean resultado = false;
        String remover = "DELETE FROM Time WHERE nome = ?";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(remover);

            comando.setString(1, nome);

            comando.execute();
            resultado = true;

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }

    public boolean atualizar(Time time) {

        boolean resultado = false;

        String atualizar = "UPDATE Time set nome = ?, curso_id = ?, modalidade_id = ? WHERE nome = ?";

        Connection con = Conexao.conectar();

        try {

            PreparedStatement comando = con.prepareStatement(atualizar);

            comando.setString(1, time.getNome());
            comando.setInt(2, time.getCurso().getId());
            comando.setInt(3, time.getModalidade().getId());

            comando.execute();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return resultado;
    }
    
    public List<Time> selecionarTimes() {

        ArrayList<Time> lista = new ArrayList<Time>();
        
        PreparedStatement comando = null;
        
        String selecionarCursos = "SELECT * FROM time;";

        Connection con = Conexao.conectar();

        try {

            comando = con.prepareStatement(selecionarCursos);
            
            ResultSet rSet = comando.executeQuery();

            while (rSet.next()) {

                Time time = new Time();

                time.setNome(rSet.getString("nome"));
               
                lista.add(time);

            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return lista;
    }
    
    public List<Jogador> selecionarJogTime(Time time){
        
        ArrayList<Jogador> lista = new ArrayList<Jogador>();
        
        PreparedStatement comando = null;
        
        String selecionarJogTime = "SELECT jogador.nome, jogador.matricula, jogador_time.numero_jogador FROM jogador, jogador_time WHERE jogador.matricula = jogador_time.jogador_matricula AND jogador_time.time_nome = ?;";

        Connection con = Conexao.conectar();
        
        try {

            comando = con.prepareStatement(selecionarJogTime);
            
            comando.setString(1, time.getNome());
            
            ResultSet rSet = comando.executeQuery();

            while (rSet.next()) {

                Jogador jogador = new Jogador();

                jogador.setNome(rSet.getString("nome"));
                jogador.setMatricula(rSet.getString("matricula"));
                jogador.setNumero(rSet.getInt("numero_jogador"));
                
                lista.add(jogador);

            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            Conexao.desconectar();
        }

        return lista;
    }
    
}
