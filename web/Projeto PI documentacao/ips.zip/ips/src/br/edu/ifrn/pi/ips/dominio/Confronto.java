
package br.edu.ifrn.pi.ips.dominio;

import java.util.Date;

public class Confronto {
    
    private Date horario;
    private Local local;
    private Time time1;
    private Time time2;
    
    public Confronto() {
    }
    
    public Confronto(Date horario) {
        this.horario = horario;
    }

    public Date getHorario() {
        return horario;
    }

    public void setHorario(Date horario) {
        this.horario = horario;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    public Time getTime1() {
        return time1;
    }

    public void setTime1(Time time1) {
        this.time1 = time1;
    }

    public Time getTime2() {
        return time2;
    }

    public void setTime2(Time time2) {
        this.time2 = time2;
    }
    
    
        
}
