/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrn.pi.ips.dominio;

public class Modalidade {
    
    private String nome;
    private int id;
    private Criterios criterio;

    public Modalidade() {
    }
    
    public Modalidade(String nome, int id) {
        this.nome = nome;
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Criterios getCriterio() {
        return criterio;
    }

    public void setCriterio(Criterios criterio) {
        this.criterio = criterio;
    }
    
    
}
