
package br.edu.ifrn.pi.ips.dominio;


public class Sumula {
    private int id;
    private String nome;
    private Criterios criterio;

    public Sumula() {
    }
    
    public Sumula(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Sumula(Time time1, Time time2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Criterios getCriterio() {
        return criterio;
    }

    public void setCriterio(Criterios criterio) {
        this.criterio = criterio;
    }
    
    
}
