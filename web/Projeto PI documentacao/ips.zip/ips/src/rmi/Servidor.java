package rmi;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import br.edu.ifrn.pi.ips.telas.Alerta;
import br.edu.ifrn.pi.ips.telas.Sumula;
import java.net.MalformedURLException;
import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import rmi.Servico;
import rmi.Evento;
import br.edu.ifrn.pi.ips.telas.Sumula;
import java.awt.Component;
import java.awt.Window;
import javax.swing.plaf.RootPaneUI;
import jdk.nashorn.internal.codegen.CompilerConstants;


/**
 *
 * @author yuri
 */
public class Servidor extends UnicastRemoteObject implements Servico {

    private Sumula sumula;
    
    public Servidor() throws RemoteException {
        super();
    }
    
    public Servidor(Sumula sumula) throws RemoteException{
        super();
        this.sumula = sumula;
    }

    public void executarServidor(){
        try {
            Servico stub = new Servidor();
            System.setProperty("java.rmi.server.hostname", "192.168.0.114");
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("Servidor", stub);
            System.out.println("Registrado com sucesso!");
        } catch (RemoteException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args) {

        try {
            Servico stub = new Servidor();
            System.setProperty("java.rmi.server.hostname", "192.168.0.114");
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("Servidor", stub);
            System.out.println("Registrado com sucesso!");
        } catch (RemoteException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public String enviarGol(Evento evento) throws RemoteException {
        Alerta alerta = new Alerta();
        alerta.mostrarTP(this.sumula,evento.getGol(), evento.getFalta(), evento.getNomeTime());
        System.out.println(evento.getGol());
        System.out.println(evento.getFalta());
        System.out.println(evento.getNomeTime());

        
        
        return ("Sucesso !!!");
    }
    
    @Override
    public String enviarFalta(Evento evento) throws RemoteException {
        Sumula sumula = new Sumula();
        JOptionPane.showInputDialog(sumula, "Nº do jog", evento.getFalta() + " do " + evento.getNomeTime(), 0);
        return ("Sucesso !!!");
    }

    @Override
    public String getDataHora() throws RemoteException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
        return sdf.format(Calendar.getInstance().getTime());
    }

    @Override
    public String inverteString(String string) throws RemoteException {
        String retorno = "";
        StringBuffer strb = new StringBuffer(string);
        retorno = strb.reverse().toString();
        return retorno;
    }
}
