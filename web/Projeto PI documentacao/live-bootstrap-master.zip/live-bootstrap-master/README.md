# Introdução ao Bootstrap

Assista a vídeo aula de Boostrap em nosso canal do Youtube e faça download desta página para utilizar de base para criação da sua single page.

Aulas de referência:

- [Primeiros passos com HTML - Parte I](https://www.youtube.com/watch?v=owefhaTT0AQ&feature=youtu.be)
- [Primeitos passos com HTML - Parte II](https://www.youtube.com/watch?v=gFf9ChNyCJA)
- [Introdução ao CSS com BEM (Block Element Modifier)](https://www.youtube.com/watch?v=vrmh9LzFqCM)
- [Construindo uma página web com bootstrap](https://www.youtube.com/watch?v=2sHjaOfAlbA)


Para fazer download, clique no botão ``clone or download`` e baixe o Zip.
<img width="100%"
src="https://cloud.githubusercontent.com/assets/2198735/25300544/ea6e0726-26e7-11e7-88e2-d9b3fa8aaba2.png">

# Importante

Para o curso de JS + Web Analytics (29/04 em SP), é importante você levar esta página **pronta para aula**. Seria super legal você melhorar o layout desta página também! 
