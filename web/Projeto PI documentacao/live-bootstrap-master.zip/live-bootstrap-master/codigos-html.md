<div class="calculator">
                            <input type="text" id="visor" readonly>
                            <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                              <div class="row">
                            <div class="linha">
                              <button class="key key-value" value="1">1</button>
                              <button class="key key-value" value="2">2</button>
                              <button class="key key-value" value="3">3</button>
                              <button class="key key-value last" value="0">0</button>
                            </div>
                            <div class="linha">
                              <button class="key key-value" value="4">4</button>
                              <button class="key key-value" value="5">5</button>
                              <button class="key key-value" value="6">6</button>
                              <button class="key key-cl last action instant" value="cl">cl</button>
                            </div>
                            <div class="linha">
                              <button class="key key-value" value="7">7</button>
                              <button class="key key-value" value="8">8</button>
                              <button class="key key-value" value="9">9</button>
                              <button class="key key-calc last action instant" value="=">=</button>
                            </div>
                            <div class="linha">
                              <button class="key key-value action" value="+">+</button>
                              <button class="key key-value action" value="-">-</button>
                              <button class="key key-value action" value="*">x</button>
                              <button class="key key-value last action" value="/">/</button>
                            </div>
                            </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                              <div class="row">
                                <ul id="historico">
                                  <li>Histórico da Calculadora</li>
                                </ul>
                              </div>
                            </div>
                            <div class="clearfix"></div>
                          </div>
                          
                       
