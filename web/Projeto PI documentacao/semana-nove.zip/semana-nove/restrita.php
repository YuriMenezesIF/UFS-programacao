<?php
  require_once'model/Usuario.php';
  $usuario = new Usuario();
  $usuario->setEmail("adm@login.com");
  $usuario->setSenha("123");
  //Inicia as sessões ($_SESSION) do PHP
  session_start();
  $loginOK = true;

  if ($usuario->getEmail() != $_POST["email"]) {
    $loginOk = false;
    $_SESSION["msg"] = "Usuário não encontrado!";
  }
  if ($usuario->getSenha() != $_POST["senha"]) {
    $loginOk = false;
    $_SESSION["msg"] = "Senha inválida!";
  }
 if(! $loginOK){
    header("Location: metodos.php");
  }
  $_SESSION["usuário"] = $_POST["email"];
?>
<!DOCTYPE html>
<html lang="pt">
  <head>
    <meta charset="utf-8">
    <title>Restrita</title>
  </head>
  <body>
    <h2>Dados do formulário</h2>

    <?php
      // Para testar se os dados estão chegando corretamente
      //print_r($_GET);

      echo "Você logou com o e-mail " . $_POST["email"];
      echo " e com a senha " . $_POST["senha"];
    ?>

    <a href="metodos.php">Voltar</a>
  </body>
</html>
